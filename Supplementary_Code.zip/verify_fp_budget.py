"""Check the conditional false-positive bound in Supplement B.1.
The report law is fixed to Box 1. No calibration or human data are implied.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path

if not __debug__:
    raise RuntimeError(
        "Verification requires Python assertions. Run without -O or -OO "
        "and unset PYTHONOPTIMIZE."
    )
import argparse,json
REPORTS={(1,1,1):F(2,5),(0,0,1):F(1,5),(0,0,0):F(2,5)}
GRID=[F(0),F(1,100),F(1,40),F(1,20),F(1,10),F(1,5),F(3,10),F(39,100),F(2,5),F(1,2),F(3,4),F(1)]
def upper(phi):return min(F(1),F(3,5)/(1-phi)) if phi<1 else F(1)
def witness(phi,which):
 if which=='lower':return [((1,1,1),r,p) if r!=(0,0,0) else ((0,0,0),r,p) for r,p in REPORTS.items()]
 p=max(F(0),(F(2,5)-phi)/(1-phi)) if phi<1 else F(0)
 return [((1,1,1),(1,1,1),p),((0,0,1),(1,1,1),F(2,5)-p),((0,0,1),(0,0,1),F(1,5)),((0,0,1),(0,0,0),F(2,5))]
def check(rows,phi,target):
 assert sum(p for a,r,p in rows)==1
 assert all(p>=0 for a,r,p in rows)
 for report,mass in REPORTS.items():assert sum(p for a,r,p in rows if r==report)==mass
 for k in range(3):
  fp=sum(p for a,r,p in rows if r[k]==1 and a[k]==0)
  absent=sum(p for a,r,p in rows if a[k]==0)
  assert fp<=phi*absent
 assert sum(p for a,r,p in rows if a[0]==0 and a[2]==1)==target
def lp(phi):
 import numpy as np
 from scipy.optimize import linprog
 states=[(a,r) for a in product((0,1),repeat=3) for r in REPORTS]
 eq=np.array([[float(r==rr) for a,r in states] for rr in REPORTS])
 rhs=np.array([float(v) for v in REPORTS.values()])
 ub=np.array([[float((r[k]==1 and a[k]==0)-phi*(a[k]==0)) for a,r in states] for k in range(3)])
 obj=np.array([float(a[0]==0 and a[2]==1) for a,r in states])
 result=[]
 for sign in (1,-1):
  fit=linprog(sign*obj,A_eq=eq,b_eq=rhs,A_ub=ub,b_ub=np.zeros(3),bounds=(0,None),method='highs')
  assert fit.success,fit.message;result.append(float(obj@fit.x))
 assert abs(result[0])<1e-9 and abs(result[1]-float(upper(phi)))<1e-9,(phi,result)
 return result
def run(use_lp=False):
 result=[]
 for phi in GRID:
  lo=witness(phi,'lower');hi=witness(phi,'upper');u=upper(phi)
  check(lo,phi,F(0));check(hi,phi,u)
  for weight in [F(1,4),F(1,2),F(3,4)]:check([(a,r,p*(1-weight)) for a,r,p in lo]+[(a,r,p*weight) for a,r,p in hi],phi,u*weight)
  row=dict(phi=str(phi),analytic=[str(F(0)),str(u)],endpoint_witnesses=2,interior_mixtures=3)
  if use_lp:row['LP']=lp(phi)
  result.append(row)
 assert upper(F(0))==F(3,5) and upper(F(1,10))==F(2,3) and upper(F(1,5))==F(3,4) and upper(F(2,5))==1
 return dict(status='PASS',scope='Box 1 population report law; conditional false-positive upper bound at each of three indices; false negatives unrestricted',
             result='[0, min(1, 3/(5(1-phi)))] for 0<=phi<1; [0,1] for phi=1',
             endpoint_witness_checks=24,interior_mixture_checks=36,LP_scenarios=12 if use_lp else 0,grid=result,
             caution='A conditional error probability is not a joint error-mass budget. The bound does not estimate phi, attribute error to elicitation, or transport to an unprobed history.')
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--lp',action='store_true');ap.add_argument('--output',default='fp_budget_results.json');args=ap.parse_args()
 result=run(args.lp);Path(args.output).write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in result.items() if k not in ['grid','caution']}))
