# Supplementary verification code

These scripts reproduce the synthetic calculations in Box 1 and Supplements B and C.

## Exact checks

Run with Python 3.10 or later. The exact calculations use the standard library.
Verification requires assertions to be enabled. Run without `-O` or `-OO` and
leave `PYTHONOPTIMIZE` unset.

    python check_results.py --output results.json
    python verify_fp_budget.py --output fp_budget_results.json

The first script checks the report-law bounds in Table B.1, except for the last
row, which is checked by the second script. It also checks the person-fixed
transition contrast, the counterexample with positive report cells, and the
restricted response models. In `results.json`, the `coordination` field records
the extended model's two task-success probabilities from Eq. (C.2).

## Numerical cross-checks

The pinned optional versions were verified with Python 3.12. To reproduce the
numerical cross-checks, install the dependencies in that environment:

    python -m pip install -r requirements-optional.txt
    python check_results.py --lp --output results.json
    python verify_fp_budget.py --lp --output fp_budget_results.json

The supplied results include 147 linear-program scenarios in the first script
and 12 in the second. Each scenario is minimized and maximized. The first script
also checks 168 baseline-sensitivity and 114 common-sensitivity endpoint
witnesses. The second checks 24 endpoints and 36 interior mixtures for the
conditional false-positive bound. The analytic proofs cover the continuous
parameter ranges, and the numerical checks cover finite grids.

The restriction in Eq. (B.2) is `P(R=1,A=0) <= phi*P(A=0)` at each index.
All inputs are synthetic. Sensitivity and false-positive parameters are supplied
by the examples. The code is distributed under the MIT license in `LICENSE`.

## AI assistance

OpenAI Codex assisted with implementing and checking the scripts. The checks use
exact arithmetic, constructive examples, and independent linear programs.
