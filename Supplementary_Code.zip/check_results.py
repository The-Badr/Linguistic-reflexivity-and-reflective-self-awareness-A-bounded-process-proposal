"""Reproduce the synthetic calculations in Box 1 and Supplements B and C.

Python >=3.10. Standard-library exact checks run without dependencies.
Add --lp for the optional NumPy/SciPy finite linear-programming cross-check.
No human data, Monte Carlo power claim, or empirically calibrated parameter.
The source project is distributed under the accompanying MIT license.
"""
from fractions import Fraction as F
from itertools import product
import argparse,json,math,sys
from pathlib import Path

if not __debug__:
    raise RuntimeError(
        "Verification requires Python assertions. Run without -O or -OO "
        "and unset PYTHONOPTIMIZE."
    )

REPORTS={(1,1,1):F(2,5),(0,0,1):F(1,5),(0,0,0):F(2,5)}

def summarize(witness,common=None,baseline=None,no_exits=False,fixed=False):
    assert sum(m for a,r,m in witness)==1
    assert all(m>=0 for a,r,m in witness)
    law={r:sum(m for a,rr,m in witness if rr==r) for r in REPORTS}
    assert law==REPORTS
    assert all(all(r[k]<=a[k] for k in range(3)) for a,r,m in witness if m)
    awareness=[sum(m*a[k] for a,r,m in witness) for k in range(3)]
    reporting=[sum(m*r[k] for a,r,m in witness) for k in range(3)]
    sensitivity=[reporting[k]/awareness[k] if awareness[k] else None for k in range(3)]
    if common is not None:assert sensitivity==[common]*3
    if baseline is not None:assert sensitivity[0]==baseline
    if no_exits:assert all(a[0]<=a[2] for a,r,m in witness if m)
    if fixed:assert all(r==(0,0,0) or r==a for a,r,m in witness if m)
    theta=sum(m*(a[0]==0 and a[2]==1) for a,r,m in witness)
    return {'theta':theta,'awareness':awareness,'sensitivity':sensitivity,
            'witness':[{'A':a,'R':r,'mass':m} for a,r,m in witness if m]}

def no_exit_witness(s):
    b=F(2,5)/s-F(2,5);e=F(3,5)/s-F(3,5)
    return [((1,1,1),(1,1,1),F(2,5)),((0,0,1),(0,0,1),F(1,5)),
            ((1,1,1),(0,0,0),b),((0,0,1),(0,0,0),e-b),
            ((0,0,0),(0,0,0),F(2,5)-e)]

def baseline_witness(s,upper):
    p=F(2,5)/s;q=p-F(2,5);b=min(F(1,5),q);c=q-b
    # Always make the treatment-positive reporters aware. The report-zero group
    # is treatment-aware only for the upper endpoint (or when needed by R).
    return [((1,1,1),(1,1,1),F(2,5)),
            ((1,0,1),(0,0,1),b),((0,0,1),(0,0,1),F(1,5)-b),
            ((1,0,int(upper)),(0,0,0),c),
            ((0,0,int(upper)),(0,0,0),F(2,5)-c)]

def common_bounds(s):
    return F(1,5)/s,min(F(3,5)/s-F(2,5),1-F(2,5)/s)

def common_witness(s,theta):
    pb=F(2,5)/s;pt=F(3,5)/s;h=pt-theta
    cells={(1,1):h,(1,0):pb-h,(0,1):pt-h,(0,0):1-pb-pt+h}
    w=[((1,1,1),(1,1,1),F(2,5))];cells[(1,1)]-=F(2,5)
    need=F(1,5);partial=[]
    for cell in [(0,1),(1,1)]:
        take=min(need,cells[cell]);need-=take;cells[cell]-=take
        partial.append((cell,(0,0,1),take))
    assert need==0 and min(cells.values())>=0
    partial.extend((cell,(0,0,0),mass) for cell,mass in cells.items())
    need_control=pb-F(2,5)
    for (ab,at),r,mass in partial:
        take=min(need_control,mass);need_control-=take
        w.extend([((ab,1,at),r,take),((ab,0,at),r,mass-take)])
    assert need_control==0
    return w

def exact_checks():
    result={}
    result['perfect_reporting']=summarize(no_exit_witness(F(1)),common=F(1),no_exits=True)
    result['no_transition']=summarize([((1,1,1),(1,1,1),F(2,5)),
        ((1,1,1),(0,0,1),F(1,5)),((0,0,0),(0,0,0),F(2,5))])
    assert result['perfect_reporting']['theta']==F(1,5)
    assert result['no_transition']['theta']==0
    result['constant_unknown_s_4_5']=summarize(no_exit_witness(F(4,5)),common=F(4,5),no_exits=True)
    baseline=[];common=[];unknown=[]
    for denominator in [10,25,100]:
        for numerator in range(math.ceil(.4*denominator),denominator+1):
            s=F(numerator,denominator);bounds=(max(0,F(3,5)-F(2,5)/s),1-F(2,5)/s)
            for upper,expected in zip([False,True],bounds):
                r=summarize(baseline_witness(s,upper),baseline=s)
                assert r['theta']==expected
            baseline.append({'s':s,'bounds':bounds})
        for numerator in range(math.ceil(.6*denominator),denominator+1):
            s=F(numerator,denominator);bounds=common_bounds(s)
            for expected in bounds:
                r=summarize(common_witness(s,expected),common=s)
                assert r['theta']==expected
            common.append({'s':s,'bounds':bounds})
            r=summarize(no_exit_witness(s),common=s,no_exits=True)
            assert r['theta']==F(1,5)/s
            unknown.append({'s':s,'theta':r['theta']})
    result['baseline_grid']=baseline;result['common_grid']=common
    result['no_exit_grid']=unknown
    fixed_low=[((1,1,1),(1,1,1),F(2,5)),((0,0,1),(0,0,1),F(1,5)),((0,0,0),(0,0,0),F(2,5))]
    fixed_high=[*fixed_low[:2],((0,0,1),(0,0,0),F(2,5))]
    result['fixed_endpoints']=[summarize(x,fixed=True) for x in [fixed_low,fixed_high]]
    assert [r['theta'] for r in result['fixed_endpoints']]==[F(1,5),F(3,5)]
    result['known_baseline_4_5']=[summarize(baseline_witness(F(4,5),u),baseline=F(4,5)) for u in (False,True)]
    result['known_common_4_5']=[summarize(common_witness(F(4,5),t),common=F(4,5)) for t in common_bounds(F(4,5))]
    a,w,c0,c1=F(4,5),F(1,2),F(1,5),F(3,5)
    pr=F(1,2)+F(1,2)*a*w
    pc=[F(1,2)+F(1,2)*(a*w+(1-a*w)*c) for c in (c0,c1)]
    assert (pr,*pc)==(F(7,10),F(19,25),F(22,25))
    result['response_model']={'retrieval':pr,'coordination':pc,'G':pc[1]-pc[0],
        'retrieval_equivalent_products':[2*p-1 for p in pc]}
    return result

def lp_check():
    import numpy as np
    from scipy.optimize import linprog
    a_states=list(product((0,1),repeat=3))
    cases=[]
    def solve(name,predicate,expected,s=None,sb=None):
        states=[(a,r) for a in a_states for r in REPORTS if predicate(a,r)]
        rows=[[float(r==rr) for a,r in states] for rr in REPORTS]
        values=[float(REPORTS[r]) for r in REPORTS]
        if sb is not None:
            rows.append([float(r[0]-sb*a[0]) for a,r in states]);values.append(0.)
        if s is not None:
            for k in range(3):
                rows.append([float(r[k]-s*a[k]) for a,r in states]);values.append(0.)
        c=np.array([float(a[0]==0 and a[2]==1) for a,r in states])
        matrix=np.array(rows);rhs=np.array(values);bounds=[];resid=[]
        for sign in (1,-1):
            opt=linprog(sign*c,A_eq=matrix,b_eq=rhs,bounds=(0,None),method='highs')
            assert opt.success,(name,opt.message)
            bounds.append(float(c@opt.x));resid.append(float(np.max(np.abs(matrix@opt.x-rhs))))
        assert max(abs(bounds[k]-float(expected[k])) for k in (0,1))<1e-8,(name,bounds,expected)
        cases.append({'name':name,'computed':bounds,'analytic':[float(x) for x in expected],'max_equality_residual':max(resid)})
    nfp=lambda a,r:all(r[k]<=a[k] for k in range(3))
    solve('unrestricted',lambda a,r:True,(0,1))
    solve('no_false_positives',nfp,(0,F(3,5)))
    solve('person_fixed',lambda a,r:r==(0,0,0) or r==a,(F(1,5),F(3,5)))
    for numerator in range(40,101):
        s=F(numerator,100)
        solve('baseline_'+str(s),nfp,(max(0,F(3,5)-F(2,5)/s),1-F(2,5)/s),sb=s)
    for numerator in range(60,101):
        s=F(numerator,100)
        solve('common_'+str(s),nfp,common_bounds(s),s=s)
        solve('common_no_exit_'+str(s),lambda a,r:nfp(a,r) and a[0]<=a[2],(F(1,5)/s,)*2,s=s)
    return {'cases':cases,'count':len(cases),'maximum_equality_residual':max(x['max_equality_residual'] for x in cases),
        'numpy':np.__version__,'scipy':__import__('scipy').__version__}

def encode(x):
    if isinstance(x,F):return {'fraction':str(x),'decimal':float(x)}
    raise TypeError(type(x).__name__)

def additional_checks():
    """Exact checks for the additional Supplement B/C constructions."""
    def describe(rows):
        assert sum(m for a,r,m in rows)==1
        assert all(m>=0 and all(r[k]<=a[k] for k in range(3)) for a,r,m in rows)
        laws={name:{str(i)+str(j):sum(m for a,r,m in rows if (r[0],r[col])==(i,j))
                    for i,j in product((0,1),repeat=2)} for name,col in [('control',1),('treatment',2)]}
        prevalence=[sum(m*a[k] for a,r,m in rows) for k in range(3)]
        sensitivity=[sum(m*r[k] for a,r,m in rows)/prevalence[k] for k in range(3)]
        tt=sum(m for a,r,m in rows if a[0]==0 and a[2]==1)
        tc=sum(m for a,r,m in rows if a[0]==0 and a[1]==1)
        return dict(report_pairs=laws,theta_T=tt,theta_C=tc,delta=tt-tc,
                    sensitivity=sensitivity)

    # The all-positive example, expressed using this verifier's
    # (A,R,mass) convention. Independent Ab,Ac~Bernoulli(.5), At~Bernoulli(.75),
    # and person-fixed kappa~Bernoulli(.8); compare with perfect reporting.
    imperfect=[]
    for a in product((0,1),repeat=3):
        mass=F(1,4)*(F(3,4) if a[2] else F(1,4))
        for kappa in (0,1):
            imperfect.append((a,tuple(kappa*x for x in a),mass*(F(4,5) if kappa else F(1,5))))
    perfect=[(r,r,m) for a,r,m in imperfect]
    p,q=describe(perfect),describe(imperfect)
    assert p['report_pairs']==q['report_pairs']
    assert all(v>0 for law in p['report_pairs'].values() for v in law.values())
    assert p['sensitivity']==[F(1)]*3 and q['sensitivity']==[F(4,5)]*3
    assert (p['theta_T'],q['theta_T'])==(F(3,10),F(3,8))

    # Sharp transition-contrast endpoints for the ORIGINAL Box 1 report law.
    # In the report-000 group, kappa=0 permits any awareness triple.
    fixed=[]
    for latent in [(0,1,0),(0,0,1)]:
        rows=[((1,1,1),(1,1,1),F(2,5)),((0,0,1),(0,0,1),F(1,5)),
              (latent,(0,0,0),F(2,5))]
        summarize(rows,fixed=True)
        fixed.append(describe(rows))
    assert [x['delta'] for x in fixed]==[F(-1,5),F(3,5)]
    # Enumerate every possible contribution from the only free report group.
    values=[F(1,5)+F(2,5)*((a[0]==0 and a[2]==1)-(a[0]==0 and a[1]==1))
            for a in product((0,1),repeat=3)]
    assert (min(values),max(values))==(F(-1,5),F(3,5))

    return dict(nonzero_cells=dict(perfect=p,imperfect=q),
                fixed_rule_transition_contrast=dict(bounds=(F(-1,5),F(3,5)),witnesses=fixed))


def delta_lp_check():
    """Independent finite LP check for delta under the person-fixed rule."""
    import numpy as np
    from scipy.optimize import linprog
    states=[(a,r) for a in product((0,1),repeat=3) for r in REPORTS
            if r==(0,0,0) or r==a]
    matrix=np.array([[float(r==rr) for a,r in states] for rr in REPORTS])
    rhs=np.array([float(REPORTS[rr]) for rr in REPORTS])
    c=np.array([float((a[0]==0 and a[2]==1)-(a[0]==0 and a[1]==1)) for a,r in states])
    bounds=[]
    for sign in (1,-1):
        opt=linprog(sign*c,A_eq=matrix,b_eq=rhs,bounds=(0,None),method='highs')
        assert opt.success
        bounds.append(float(c@opt.x))
    assert abs(bounds[0]+.2)<1e-9 and abs(bounds[1]-.6)<1e-9
    return dict(computed=bounds,analytic=[-.2,.6],cases=1)



if __name__=='__main__':
    arg=argparse.ArgumentParser();arg.add_argument('--lp',action='store_true');arg.add_argument('--output',default='results.json')
    opt=arg.parse_args();result={'status':'PASS','scope':'Box 1 and Supplements B and C: synthetic populations and response models','exact':exact_checks(),'additional':additional_checks()}
    if opt.lp:
        result['linear_programming']=lp_check();result['additional_linear_programming']=delta_lp_check()
    Path(opt.output).write_text(json.dumps(result,default=encode,indent=2),encoding='utf-8')
    print(json.dumps({'status':'PASS','exact_baseline_witness_checks':2*len(result['exact']['baseline_grid']),'exact_common_witness_checks':2*len(result['exact']['common_grid']),'lp_cases':result.get('linear_programming',{}).get('count',0)+result.get('additional_linear_programming',{}).get('cases',0)}))
